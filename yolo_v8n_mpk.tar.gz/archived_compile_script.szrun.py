#!/usr/bin/env python3

# Command line program to invoke run recipes for the model zoo.

# Python base modules
import os
import sys
import pwd
import argparse
from argparse import ArgumentParser, ArgumentTypeError

# Project modules
from simazoo.foundation.zoo_model import MLZooModel
from simazoo.exec.run_sdk import run_zoo_model, run_sdk_model


def get_args():
    # 2 types of models:
    #   1. python
    #   2. YAML
    #
    parser = argparse.ArgumentParser(description=f"Model Zoo run script")
    # Run type options
    # ------------------------------------------------------------------------------
    parser.add_argument('-c', '--config', type=str, default="", help="YAML configuration for the model")
    parser.add_argument('-p', '--pyfile', type=str, default="", help="Python defintion of the model")
    # Options for any model
    # ------------------------------------------------------------------------------
    parser.add_argument('-f', '--mfile', type=str, default="", help="File of the model to use")
    parser.add_argument('-d', '--dset', type=str, default="", help="Location of dataset base directory")
    parser.add_argument('-s', '--test_samples', type=int, default=-1, help='Number of samples to use for accuracy testing')
    parser.add_argument('-q', '--quant_samples', type=int, default=-1, help='Number of samples to use for quantization')
    parser.add_argument('-w', '--work_dir', type=str, default=os.getcwd(), help='Working directory for outputs')
    parser.add_argument('--cml_proj', type=str, help="clear.ml project name")
    parser.add_argument('-no_compile', '--no_compile_flag', action='store_true', help="Activate no_compile flag for skipping MLA compile() step")
    parser.add_argument('-no_fp32_onnx', '--no_fp32_onnx_flag', action='store_true', help="Activate no_fp32_onnx flag for skipping fp32 and onnx pipeline step")
    parser.add_argument('-no_x86_FP32', '--no_x86_FP32_flag', action='store_true', help="Activate no_x86_FP32 flag for skipping the evaluation of Model x86.FP32")
    parser.add_argument('-no_x86_INT8', '--no_x86_INT8_flag', action='store_true', help="Activate no_x86_INT8 flag for skipping the evaluation of Model x86.INT8")
    parser.add_argument('-platform_target', '--platform_target', type=str, required=False, default="gen2_target",
                        help="Platform target to compile, and produce ELF File(s). Currently, the only valid input is gen2_target for Michelangelo.")
    all_args = parser.parse_args()
    return all_args

def run_zoo_recipe(cmd_args: argparse.Namespace, zoo_model: MLZooModel) -> bool:
    """ Runs all the zoo regression steps on the given model.
    """
    # Step 1: run all the baseline steps (bare fp32 sim, baseline quantization, bline quant sim)
    #rc = int(run_zoo_model(cmd_args, zoo_model, clear_task))
    rc = int(run_zoo_model(cmd_args, zoo_model))
    # DEBUG: shortcut
    # return True
    if zoo_model.status != 'Exempt':
        #rc = run_sdk_model(cmd_args, zoo_model, clear_task)
        rc = run_sdk_model(cmd_args, zoo_model)
    else:
        print(f"Model is exempt from the SDK phase, skipping.")

    print(f"\nModel run complete with the return code is {rc}.\n\n")
    return rc


def build_zoo_model(cmd_args: argparse.Namespace) -> MLZooModel:
    """ Builds the appropriate model zoo object based on the user settings.
    """
    # First check to see if this is a YAML model or a Python one.
    if len(cmd_args.config) > 0:
        from simazoo.modeldefs.yaml_model import YAMLZooModel

        zoo_model = YAMLZooModel(
                        yaml_file=cmd_args.config,
                        ds_root=cmd_args.dset,
                        mfile=cmd_args.mfile,
                        work_dir=cmd_args.work_dir,
                        platform_target= cmd_args.platform_target
                    )
    else:
        from simazoo.utils import class_def_iter

        # Python based model
        # Here we need to read in the Python file, import it as a module,
        # and do simple checks for completeness. We look for code under the $CWD or below
        # directories.
        zoo_model = None
        for cname, cdef in class_def_iter(
            base_dir=os.path.curdir,
            class_type=MLZooModel
        ):
            # We will pass in a default dictionary that constructors accept.
            model_params = {'work_dir':cmd_args.work_dir, 'mfile':cmd_args.mfile, 'ds_root':cmd_args.dset}
            zoo_model = cdef(**model_params)
            break
    return zoo_model

    
def main(cmd_args: argparse.Namespace) -> bool:
    """ This is the main code entry point for the generalized run script. It's designed to start from a
        point of only user-provided arguments, and
    """
    from pprint import pprint
    print("Using run options:")
    pprint(cmd_args.__dict__)

    # platform_target
    if cmd_args.platform_target:
        if cmd_args.platform_target == "gen2_target":
            print(f"INFO: Platform target {cmd_args.platform_target} to compile, and produce ELF File(s)")
        else:
            print(f"ERROR: Invalid input {cmd_args.platform_target} for platform_target. Currently, "
                  f"the only valid input is gen2_target for Michelangelo. Exiting ...")
            sys.exit(-1)
    else:
        print("INFO: Not provide the value for cmd_args.platform_target")

    zoo_model = build_zoo_model(cmd_args)
    if zoo_model is None:
        print(f"Error: failed to read zoo model!")
        return False
    rc = run_zoo_recipe(cmd_args, zoo_model)
    return rc

if __name__ == "__main__":
    command_line_args = get_args()
    main(command_line_args)
